/**
 * Voxly Stream — Cloudflare Pages "advanced mode" worker
 *
 * Lives inside the same Pages project (no separate Worker needed).
 * Only POST /api/download is handled here; every other URL is served as a normal static file.
 *
 *   POST /api/download   body: { "token": "<Turnstile token>" }
 *     1. Verify the token with Cloudflare Turnstile.
 *     2. If valid, reply { "downloadUrl": "<GitHub Release link>" }.
 *        The browser then downloads straight from GitHub (fast, native progress,
 *        and no "dangerous file" warning caused by the Pages domain).
 *
 * Set in Pages -> your project -> Settings -> Variables and secrets (Production):
 *   TURNSTILE_SECRET  (Secret)  Turnstile secret key
 *   APK_URL           (Text)    direct link to the .apk in a PUBLIC GitHub Release
 * After adding or changing variables, redeploy the project so they apply.
 */

const SITEVERIFY_URL = "https://challenges.cloudflare.com/turnstile/v0/siteverify";

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/api/download") {
      return handleDownload(request, env, url);
    }
    // Everything else: normal static site (pages, _redirects, 404.html ...)
    return env.ASSETS.fetch(request);
  },
};

async function handleDownload(request, env, url) {
  const t0 = Date.now();
  if (request.method !== "POST") {
    return json({ error: "Method not allowed" }, 405, { Allow: "POST" });
  }
  // Same-origin only: the request must come from this site's own pages.
  const origin = request.headers.get("Origin");
  if (!origin || origin !== url.origin) {
    return json({ error: "Forbidden origin" }, 403);
  }
  if (!env.TURNSTILE_SECRET || !env.APK_URL) {
    return json({ error: "Server is not configured" }, 500);
  }

  // --- 1. Read the token ---
  let token;
  try {
    ({ token } = await request.json());
  } catch (_) {
    return json({ error: "Invalid request body" }, 400);
  }
  if (typeof token !== "string" || token.length === 0 || token.length > 2048) {
    return json({ error: "Missing token" }, 400);
  }

  // --- 2. Verify with Turnstile ---
  const form = new FormData();
  form.append("secret", env.TURNSTILE_SECRET);
  form.append("response", token);
  const ip = request.headers.get("CF-Connecting-IP");
  if (ip) form.append("remoteip", ip);

  let outcome;
  const tVerify = Date.now();
  try {
    const res = await fetch(SITEVERIFY_URL, { method: "POST", body: form });
    outcome = await res.json();
  } catch (_) {
    return json({ error: "Verification service unavailable" }, 502);
  }
  if (!outcome.success) {
    return json({ error: "CAPTCHA verification failed" }, 403);
  }

  // --- 3. Token is valid: hand out the download link ---
  // `timing` (ms) is only used by the page's ?debug mode to find slow steps.
  return json({
    downloadUrl: env.APK_URL,
    timing: { verify: Date.now() - tVerify, total: Date.now() - t0 },
  }, 200);
}

function json(body, status, extra = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store", ...extra },
  });
}
